import { loadConfig, safeJsonParse, finalizeMessages } from "./utils";

export default class Agent {
  constructor(runner, name) {
    this.runner = runner;
    this.settings = loadConfig(name);
  }

  onStart(snapshot) {
    this.snapshot = snapshot;
    if (!this.snapshot.saves) this.snapshot.saves = {};
    const instructions = this.settings?.instructions;

    if (instructions) {
      return finalizeMessages(instructions, this.snapshot, this.snapshot.saves);
    }
  }

  onGenerate(message) {
    if (message.parsedContent.saves) {
      const saves = message.parsedContent.saves;
      if (!this.snapshot.saves) this.snapshot.saves = {};
      for (const save of saves) {
        this.snapshot.saves[save.name] = save.value;
      }
    }

    return { ...message, snapshot: this.snapshot };
  }

  onSubmit(data) {
    const submissions = this.settings.submissions;

    // Iterate over each key in the submitted data
    for (const key in data) {
      // Find if the key exists in the submissions array
      const submission = submissions.find((sub) => sub.key === key);

      if (submission) {
        const value = data[key];
        
        if (submission.next) {
          const next = console.render(submission.next, {value, saves: this.snapshot?.saves}).trim();
          if (next) {
            this.snapshot.agent = next;
            return this.runner.onStart(this.snapshot);
          }
        }
        
        if (submission.save) {
          this.snapshot.saves[key] = value;
        }

        const message = submission.message;
        return finalizeMessages([message], this.snapshot, {value, saves: this.snapshot?.saves});
      }
    }

    console.log("submission handler not found:", data);
  }
}
