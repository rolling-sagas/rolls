// @entry
import { safeJsonParse, loadConfig } from "./utils";
import Agent from "./agent";

class Runner {
  constructor() {
    this.settings = loadConfig("settings");
  }

  onStart(snapshot) {
    if (typeof snapshot === "string") {
      snapshot = safeJsonParse(snapshot);
    }

    console.log("on start:", snapshot);

    this.nextAgent(snapshot);
    return this.agent.onStart(this.snapshot);
  }

  onGenerate(message) {
    message = safeJsonParse(message);
    message.parsedContent = safeJsonParse(message.content);
    return this.agent?.onGenerate(message);
  }

  onSubmit(data) {
    data = safeJsonParse(data);
    return this.agent?.onSubmit(data);
  }

  nextAgent(snapshot) {
    const agentName = snapshot?.agent || this.settings.starting_agent;
    
    this.snapshot = snapshot || { agent: agentName };
    this.agent = new Agent(this, agentName);
  }
}

export default new Runner();
