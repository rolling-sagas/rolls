export function safeJsonParse(input) {
  // Early return if the input isn’t a string
  if (typeof input !== "string") {
    return undefined;
  }

  try {
    return JSON.parse(input);
  } catch (error) {
    // Return undefined (or your fallback) when parsing fails
    console.log("JSON parse error:", error);
    return undefined;
  }
}

export function loadConfig(name) {
  const str = console.load(name);

  // If `console.load` did not return a string, return undefined or your preferred fallback
  if (typeof str !== "string") {
    return undefined;
  }

  try {
    // Attempt to parse as JSON
    return JSON.parse(str);
  } catch (err) {
    // If parsing fails, return undefined or your fallback
    console.log("JSON parse error:", error);
    return undefined;
  }
}

export function finalizeMessages(messages, snapshot, data) {
  if (!Array.isArray(messages)) return;
  return messages.map((msg) => {
    const rendered = console.render(msg.content, data);
    return {role: msg.role, content: rendered, snapshot};
  });
}
