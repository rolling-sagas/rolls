import Scene from "Scene";
import { shuffleAndDrawTarot } from "Utils";

function parseNumbers(text) {
  // Remove extra spaces and split by spaces or commas
  const parts = text.trim().split(/[\s,]+/);

  // Set to track used numbers
  const usedNumbers = new Set();

  // Convert each part to number and validate
  const numbers = parts.map((part) => {
    const num = Number(part);

    // Check if it's a valid number
    if (isNaN(num)) {
      throw new Error(`Invalid number: "${part}"`);
    }

    // Check range
    if (num < 0 || num > 78) {
      throw new Error(`Number ${num} is out of range (0-78)`);
    }

    // Check for duplicates
    if (usedNumbers.has(num)) {
      throw new Error(`Duplicate number: ${num}`);
    }

    usedNumbers.add(num);
    return num;
  });

  return numbers;
}

export default class ChapterIntro extends Scene {
  constructor() {
    super();
  }

  onStart(entry) {
    this.entry = entry;

    const configStr = console.load("chapter_intro");
    this.config = JSON.parse(configStr);

    const cardsStr = console.load("tarot_cards");
    this.cards = JSON.parse(cardsStr);

    const imagesStr = console.load("images");
    this.images = JSON.parse(imagesStr);

    this.entry.saved.avatar = {
      user: { name: "Seeker" },
      assistant: { name: "Reader" },
    };

    // console.log(this.images);

    return [
      { role: "divider", content: this.config.title },
      {
        role: "system",
        content: console.render(this.config.prompt, {
          images: this.images,
        }),
      },
    ];
  }

  onSubmit(data) {
    let content;

    if (data.seeker_question) {
      this.entry.saved.seeker_question = data.seeker_question;
      content = `PLAYER: My question is **${data.seeker_question}**.`;
    }

    if (data.confirm_preparation) {
      content = `PLAYER: **I'm ready!**`;
    }

    if (data.draw_cards) {
      try {
        const list = parseNumbers(data.draw_cards);
        const draws = list.map((n) => parseInt(n));
        const res = shuffleAndDrawTarot(this.cards.cards, draws);
        content = "PLAYER: I drawed three cards:";
        for (const card of res) {
          content += ` **${card.name}(${card.position})**`;
        }
        for (const card of res) {
          content += `\nHINT: show the image view, src="${card.name_short}", base="images.cards"`;
          content += `\nHINT: ${card.name} - **description**: ${card.desc.replace(/\n/, " ")} | **meaning**(${card.position}): ${card.meaning.replace(/\n/, " ")}`;
        }
      } catch (e) {
        console.log(e);
        content = `PLAYER: Invalid input: ${data.draw_cards}.\nHINT: Let the seeker input the cards number again. (${e.message})`;
      }
    }

    if (data.confirm_reading) {
      content = `PLAYER: Let's **Continue**`;
      content += `\nHINT: give the seeker a summarize for the answer to the quesiton: "${this.entry.saved.seeker_question}"`;
    }

    if (content) {
      return [{ role: "user", content: content }];
    }

    if (data.next) {
      this.entry.saved.scene = "chapter_one";
      return [{ role: "divider", content: "" }];
    }

    // if return nothing it will call start again...
    return;
  }
}
