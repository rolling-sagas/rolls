export default class Scene {
  constructor() {
    this.entry = null;
  }

  onStart(entry) {}

  onGenerate(data) {}

  onSubmit(data) {}
}
