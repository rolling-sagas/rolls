export function shuffleAndDrawTarot(cards, drawPositions) {
  // Helper function to shuffle array using Fisher-Yates algorithm
  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }

  // Validate draw positions
  if (
    !Array.isArray(drawPositions) ||
    drawPositions.some(
      (pos) => !Number.isInteger(pos) || pos < 1 || pos > cards.length,
    )
  ) {
    throw new Error(
      "Draw positions must be an array of valid integers within deck size",
    );
  }

  // Create a copy of the cards array to avoid modifying the original
  let shuffledDeck = [...cards];

  // Shuffle the deck
  shuffledDeck = shuffleArray(shuffledDeck);

  // Draw cards based on positions
  let drawnCards = drawPositions
    .map((position) => {
      const cardIndex = position - 1; // Convert to 0-based index

      // Check if position is valid
      if (cardIndex >= shuffledDeck.length) {
        return null;
      }

      // Randomly determine if card is upright or reversed
      const isReversed = Math.random() < 0.5;

      // Create drawn card object with position
      return {
        ...shuffledDeck[cardIndex],
        position: isReversed ? "rev" : "up",
        meaning: isReversed
          ? shuffledDeck[cardIndex].meaning_rev
          : shuffledDeck[cardIndex].meaning_up,
        drawnPosition: position,
      };
    })
    .filter((card) => card !== null); // Remove any null entries

  return drawnCards;
}
