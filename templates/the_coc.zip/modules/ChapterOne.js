import Scene from "./Scene";
import { skillCheck } from "./Utils";

const NAME = "chapter_one";

export default class ChapterOne extends Scene {
  constructor() {
    super();
  }

  onStart(entry) {
    this.entry = entry;

    this.entry.saved.avatar.user = {
      name: this.entry.saved.player_name,
    };

    const configStr = console.loadConfig(NAME);
    this.config = JSON.parse(configStr);

    const occupationStr = console.loadConfig(
      this.entry.saved.player_occupation,
    );
    this.occupation = JSON.parse(occupationStr);

    return [
      { role: "divider", content: this.config.title },
      { role: "system", content: this.config.prompt },
    ];
  }

  onSubmit(data) {
    let messages;

    if (data.player_action) {
      messages = [
        {
          role: "user",
          content: `PLAYER: ${data.player_action}`,
        },
      ];
    }

    if (data.skill_check) {
      const reg = /^(\w+)\((\w+)\)$/;
      const match = reg.exec(data.skill_check);
      if (match) {
        const [_, skillName, difficulty] = match;
        const skillValue = this.occupation.skills[skillName] || 15;
        console.log("skill check:", skillName, skillValue);
        const rollRes = skillCheck(
          skillName,
          skillValue,
          difficulty,
          parseInt(data.roll),
        );
        messages = [
          {
            role: "user",
            content: `PLAYER: ${rollRes.message}.`,
          },
        ];
      }
    }

    if (data.next) {
      return this.entry.nextScene("chapter_two");
    }

    if (messages && this.entry.saved.turn > 4) {
      messages[0].content +=
        "\nHINT: " + "Finish the conversation now, with a good reason.";
    }

    return messages;
  }
}
