import Scene from "./Scene";

export default class ChapterIntro extends Scene {
  constructor() {
    super();
  }

  onStart(entry) {
    this.entry = entry;

    const configStr = console.load("chapter_intro");
    this.config = JSON.parse(configStr);

    this.entry.saved.avatar = {
      user: { name: "Player" },
      assistant: { name: "Keeper" },
    };

    return [
      { role: "divider", content: this.config.title },
      { role: "system", content: this.config.prompt },
    ];
  }

  onSubmit(data) {
    let content;

    if (data.player_name) {
      this.entry.saved.player_name = data.player_name;
      this.entry.saved.avatar.user = {
        name: data.player_name,
      };
      content = `PLAYER: My name is **${data.player_name}**.`;
    }

    if (data.player_occupation) {
      this.entry.saved.player_occupation = data.player_occupation;
      const occStr = console.load(data.player_occupation);
      const parsed = JSON.parse(occStr);
      const occName = parsed?.name || data.player_occupation;
      content = `PLAYER: I choose **${occName}**.`;
    }

    if (content) {
      return [{ role: "user", content: content }];
    }

    if (data.next) {
      return this.entry.nextScene("chapter_one");
    }
  }
}
