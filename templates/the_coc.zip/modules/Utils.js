export function diceRoll(str) {
  const rollStr = console.diceRoll(str);
  return JSON.parse(rollStr);
}

export function skillCheck(skillName, skillValue, difficulty = "regular", roll = -1) {
  // Roll d100 (1-100)
  roll = roll > 0 ? roll : Math.floor(Math.random() * 100) + 1;

  // Define success thresholds based on difficulty
  const extremeSuccess = Math.floor(skillValue / 5);
  const hardSuccess = Math.floor(skillValue / 2);
  const regularSuccess = skillValue;

  // Adjust thresholds based on difficulty level
  let successThreshold;
  switch (difficulty.toLowerCase()) {
    case "extreme":
      successThreshold = extremeSuccess;
      break;
    case "hard":
      successThreshold = hardSuccess;
      break;
    case "regular":
      successThreshold = regularSuccess;
      break;
    default:
      successThreshold = regularSuccess;
  }

  // Determine result
  let result;
  let message;

  if (roll === 1) {
    result = "Critical Success";
    message = `**Outstanding**! A critical success on ${skillName}\nIGNORE: Rolled **1**!`;
  } else if (roll === 100) {
    result = "Critical Failure";
    message = `**Catastrophic**! A critical failure on ${skillName}\nIGNORE: Rolled **100**!`;
  } else if (roll <= extremeSuccess) {
    result = "Extreme Success";
    message = `**Exceptional** ${skillName} check!\nIGNORE: Rolled **${roll}**, needed ${extremeSuccess} or less.`;
  } else if (roll <= hardSuccess) {
    result = "Hard Success";
    message = `**Great** ${skillName} check!\nIGNORE: Rolled **${roll}**, needed ${hardSuccess} or less.`;
  } else if (roll <= regularSuccess) {
    result = "Regular Success";
    message = `**Successful** ${skillName} check\nIGNORE: Rolled **${roll}**, needed ${regularSuccess} or less.`;
  } else {
    result = "Failure";
    message = `**Failed** ${skillName} check\nIGNORE: Rolled **${roll}**, needed ${successThreshold} or less.`;
  }

  // Create return object
  return {
    roll,
    successThreshold,
    result,
    isSuccess: roll <= successThreshold,
    message,
    details: {
      extremeThreshold: extremeSuccess,
      hardThreshold: hardSuccess,
      regularThreshold: regularSuccess,
    },
  };
}

export function roll(skillName, skillValue, difficulty) {
  // Simulate a d100 roll (1-100)
  const roll = Math.floor(Math.random() * 100) + 1;

  // Example skill value (you'd replace this with a lookup from a character sheet)
  // const skillValue = 50; // Placeholder, adjust based on your system

  // Difficulty modifiers
  let successThreshold = skillValue;
  let criticalThreshold = Math.floor(skillValue / 5); // Critical success is 1/5 of skill
  let fumbleThreshold = 96; // Default fumble at 96+, can adjust

  // Adjust thresholds based on difficulty
  switch (difficulty.toLowerCase()) {
    case "easy":
      successThreshold = skillValue * 2; // Double the skill for easy tasks
      break;
    case "hard":
      successThreshold = Math.floor(skillValue / 2); // Half the skill for hard tasks
      criticalThreshold = Math.floor(successThreshold / 5);
      break;
    case "extreme":
      successThreshold = Math.floor(skillValue / 5); // 1/5 for extreme tasks
      criticalThreshold = Math.floor(successThreshold / 5);
      break;
    default:
      // "normal" difficulty keeps successThreshold as skillValue
      break;
  }

  // Cap successThreshold at 100
  successThreshold = Math.min(successThreshold, 100);

  // Determine result
  let result = "";
  if (roll === 1) {
    result = "Critical Success! (Automatic success)";
  } else if (roll >= fumbleThreshold && skillValue < 100) {
    result = "Fumble! (Automatic failure)";
  } else if (roll <= criticalThreshold) {
    result = "Critical Success!";
  } else if (roll <= successThreshold) {
    result = "Success!";
  } else {
    result = "Failure!";
  }

  // Format the output
  return `ROLL: ${result}\nIGNORE: Rolled ${roll} vs ${skillName} ${successThreshold}% with ${difficulty} difficulty`;
}

export function getInitial({ player, encounter }) {
  // Default sanity loss based on encounter
  let sanity_lost = 0;
  let desc = "";

  // Perform sanity check
  const sanityCheckRoll = Math.floor(Math.random() * 100) + 1;
  const sanityThreshold = encounter.sanityDifficulty || 50; // Default difficulty if not specified

  if (sanityCheckRoll > player.sanity) {
    // Failed sanity check
    sanity_lost = encounter.sanityLoss || Math.floor(Math.random() * 6) + 1; // Default 1d6 loss
    desc = `SAN Check: Failed (Rolled ${sanityCheckRoll} vs ${player.sanity}).`;
    desc += `\nPlayer loses ${sanity_lost} sanity points.`;
  } else {
    // Passed sanity check
    // desc = `Player stares into ${encounter.name} and maintains their grip on reality! `;
    desc = `SAN Check: passed (Rolled ${sanityCheckRoll} vs ${player.sanity}).`;
  }

  // Determine who acts first based on Dexterity
  const playerDex = player.dexterity || 10; // Default DEX if not specified
  const encounterDex = encounter.dexterity || 10; // Default DEX if not specified

  if (playerDex > encounterDex) {
    desc += `\nInitiative: Player wins ((DEX ${playerDex} vs ${encounterDex})`;
    desc += "\nCurrent Turn: Player acts first";
  } else if (encounterDex > playerDex) {
    desc += `\nInitiative: Player loses ((DEX ${playerDex} vs ${encounterDex})`;
    desc += "\nCurrent Turn: Enemy acts first";
  } else {
    desc += `\nPlayer act first!`;
  }

  return {
    sanity_lost,
    desc,
  };
}
