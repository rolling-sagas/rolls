import Scene from "./Scene";
import { roll, diceRoll, getInitial } from "./Utils";
import {
  dodge,
  fightBack,
  attack,
  flee,
  HealthStatus,
  calculateHealthStatus,
} from "./EncounterFunctions";

const NAME = "encounter_with";

export default class EncounterWith extends Scene {
  constructor() {
    super();
  }

  prepare() {
    // laad player's occupation config
    let configStr = console.loadConfig(this.entry.saved.player_occupation);
    if (!configStr) {
      throw new Error("occupation not found");
    }
    this.player = JSON.parse(configStr);
    this.player.name = "Me";

    // load encounter's config
    configStr = console.loadConfig(this.entry.saved.encounter.target);
    if (!configStr) {
      throw new Error("encounter's target not found");
    }
    this.encounter = JSON.parse(configStr);

    // load chapter's config
    configStr = console.loadConfig(NAME);
    if (!configStr) {
      throw new Error("scene config not found");
    }

    this.config = JSON.parse(configStr);

    // initial player' status
    if (!this.entry.saved.player_status) {
      this.entry.saved.player_status = {
        hp: this.player.hit_points,
        sanity: this.player.sanity,
        tags: [],
      };
    }

    // initial encounter's status
    // it will be deleted when the encounter finished
    if (!this.entry.saved.encounter.status) {
      this.entry.saved.encounter.status = {
        hp: this.encounter.hit_points,
        tags: [],
      };
    }

    if (!this.entry.saved.encounter.initial) {
      const initial = getInitial({
        player: this.player,
        encounter: this.encounter,
      });

      this.entry.saved.player_status.sanity -= initial.sanity_lost;
      this.entry.saved.encounter.initial = initial;
    }
  }

  onStart(entry) {
    this.entry = entry;
    this.prepare();

    return [
      {
        role: "divider",
        content: console.renderTemplate(this.config.title, {
          encounter: this.encounter,
        }),
      },
      {
        role: "system",
        content: console.renderTemplate(this.config.prompt, {
          saved: this.entry.saved,
          config: this.config,
          encounter: this.encounter,
          player: this.player,
        }),
      },
    ];
  }

  onGenerate(content) {
    const { views } = JSON.parse(content);
    const enemy_action = views.find((item) => item.type === "enemy_action");
    if (enemy_action) {
      this.entry.saved.encounter.enemy_action = enemy_action.value;
    }
  }

  onSubmit(data) {
    let message;

    if (data.next) {
      this.entry.saved.scene = this.entry.saved.encounter.next_scene;
      delete this.entry.saved.encounter;
      message = [{ role: "divider", content: "" }];
      return message;
    }

    if (data.player_action) {
      let calc;
      if (data.player_action === "flee") {
        this.encounter.attack = this.encounter.attacks[0];
        calc = flee(this.player, this.encounter);
        message = [{ role: "user", content: "PLAYER: " + calc.message }];
        if (calc.escaped) {
          message[0].content += "\nHINT: chapter ends";
          return message;
        }
      } else {
        this.player.attack = this.player.actions.find(
          (att) => att.id === data.player_action,
        );
        calc = attack(this.player, this.encounter);
      }
      message = [{ role: "user", content: "PLAYER: " + calc.message }];
      this.entry.saved.encounter.status.hp -= calc.damage;
    }

    if (data.player_reaction === "dodge") {
      this.encounter.attack = this.encounter.attacks.find(
        (att) => att.id === this.entry.saved.encounter.enemy_action,
      );
      const calc = dodge(this.encounter, this.player);
      this.entry.saved.player_status.hp -= calc.damage;
      message = [{ role: "user", content: "PLAYER: " + calc.message }];
    }

    if (data.player_reaction === "fight_back") {
      this.encounter.attack = this.encounter.attacks.find(
        (att) => att.id === this.entry.saved.encounter.enemy_action,
      );
      this.player.attack = this.player.actions.find(
        (att) => att.id === data.player_reaction,
      );
      const calc = fightBack(this.encounter, this.player);
      this.entry.saved.encounter.status.hp -= calc.defenderDamage;
      this.entry.saved.player_status.hp -= calc.attackerDamage;
      message = [{ role: "user", content: "PLAYER: " + calc.message }];
    }

    const enemyStatus = calculateHealthStatus(
      this.entry.saved.encounter.status.hp,
      this.encounter.hit_points,
    );
    const playerStatus = calculateHealthStatus(
      this.entry.saved.player_status.hp,
      this.player.hit_points,
    );
    message[0].content += `\nHINT: player: ${playerStatus.message} | enemy: ${enemyStatus.message}`;

    if (data.player_action) {
      message[0].content += ` | enemy turn`;
    }

    if (data.player_reaction) {
      message[0].content += ` | player turn`;
    }

    if (
      enemyStatus.status === HealthStatus.DEAD ||
      playerStatus.status === HealthStatus.DEAD
    ) {
      message[0].content += " | chapter ends";
    }

    return message;
  }
}
