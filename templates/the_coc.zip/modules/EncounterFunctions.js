// @see: https://cthulhuwiki.chaosium.com/rules/combat.html#close-combat
import { diceRoll } from "./Utils";

const SuccessLevel = {
  FAILURE: 0,
  REGULAR: 1,
  HARD: 2,
  EXTREME: 3,
  CRITICAL: 4,
};

// Helper function to get success level description
function getSuccessDescription(level) {
  switch (level) {
    case SuccessLevel.CRITICAL:
      return "Critical";
    case SuccessLevel.EXTREME:
      return "Extreme";
    case SuccessLevel.HARD:
      return "Hard";
    case SuccessLevel.REGULAR:
      return "Regular";
    case SuccessLevel.FAILURE:
      return "Failed";
    default:
      return "Unknown";
  }
}

function getSuccessLevel(roll, skill) {
  if (roll > skill) return SuccessLevel.FAILURE;
  if (roll === 1) return SuccessLevel.CRITICAL;
  if (roll <= Math.floor(skill / 5)) return SuccessLevel.EXTREME;
  if (roll <= Math.floor(skill / 2)) return SuccessLevel.HARD;
  return SuccessLevel.REGULAR;
}

function roll1D100() {
  return Math.floor(Math.random() * 100) + 1;
}

export function attack(attacker, defender, defenseChoice = null) {
  const attackRoll = roll1D100();
  const attackSuccess = getSuccessLevel(attackRoll, attacker.attack.skill);
  console.log("attack success:", attackSuccess);
  if (attackSuccess === SuccessLevel.FAILURE) {
    return {
      success: false,
      damage: 0,
      message: `${attacker.attack.name} misses completely! (Roll: ${attackRoll})`,
    };
  }

  if (defenseChoice === "dodge") {
    return dodge(attacker, defender, attackRoll, attackSuccess);
  }

  if (defenseChoice === "fightBack") {
    return fightBack(attacker, defender, attackRoll, attackSuccess);
  }

  const damage = calculateDamage(attackSuccess, attacker.attack.damage);
  return {
    success: true,
    damage,
    attackSuccess,
    message: `${attacker.attack.name} lands a ${getSuccessDescription(attackSuccess)} hit! (Roll: ${attackRoll}) dealing ${damage} damage with no defense!`,
  };
}

export function dodge(
  attacker,
  defender,
  preRolledAttack = null,
  preRolledSuccess = null,
) {
  const attackRoll = preRolledAttack || roll1D100();
  const dodgeRoll = roll1D100();

  const attackSuccess =
    preRolledSuccess || getSuccessLevel(attackRoll, attacker.attack.skill);
  const dodgeSuccess = getSuccessLevel(dodgeRoll, defender.skills.dodge);

  const result = {
    attackRoll,
    dodgeRoll,
    attackSuccess,
    dodgeSuccess,
    success: false,
    damage: 0,
    message: "",
  };

  if (attackSuccess > dodgeSuccess) {
    result.success = true;
    result.damage = calculateDamage(attackSuccess, attacker.attack.damage);
    result.message =
      `${attacker.attack.name} (${getSuccessDescription(attackSuccess)}) vs ${defender.name}'s dodge (${getSuccessDescription(dodgeSuccess)}). ` +
      `Hit! ${result.damage} damage.`;
  } else {
    result.message =
      `${attacker.attack.name} (${getSuccessDescription(attackSuccess)}) vs ${defender.name}'s dodge (${getSuccessDescription(dodgeSuccess)}). ` +
      `Dodge successful!`;
  }

  return result;
}

export function fightBack(
  attacker,
  defender,
  preRolledAttack = null,
  preRolledSuccess = null,
) {
  const attackRoll = preRolledAttack || roll1D100();
  const fightBackRoll = roll1D100();

  const attackSuccess =
    preRolledSuccess || getSuccessLevel(attackRoll, attacker.attack.skill);
  const fightBackSuccess = getSuccessLevel(
    fightBackRoll,
    defender.attack.skill,
  );

  const result = {
    attackRoll,
    fightBackRoll,
    attackSuccess,
    fightBackSuccess,
    attackerDamage: 0,
    defenderDamage: 0,
    winner: null,
    message: "",
  };

  if (fightBackSuccess > attackSuccess) {
    result.winner = "defender";
    result.defenderDamage = calculateDamage(
      SuccessLevel.REGULAR,
      defender.attack.damage,
    );
    result.message =
      `${attacker.name} (${getSuccessDescription(attackSuccess)}) vs ${defender.name}'s counter (${getSuccessDescription(fightBackSuccess)}). ` +
      `Counter succeeds! ${result.defenderDamage} damage.`;
  } else {
    result.winner = "attacker";
    result.attackerDamage = calculateDamage(
      attackSuccess,
      attacker.attack.damage,
    );
    result.message =
      `${attacker.name} (${getSuccessDescription(attackSuccess)}) vs ${defender.name}'s counter (${getSuccessDescription(fightBackSuccess)}). ` +
      `Hit! ${result.attackerDamage} damage.`;
  }

  return result;
}

export function flee(fleeingCharacter, pursuer) {
  // DEX check for fleeing
  const fleeRoll = roll1D100();
  const fleeSuccess = getSuccessLevel(fleeRoll, fleeingCharacter.dexterity);

  const result = {
    fleeRoll,
    fleeSuccess,
    escaped: false,
    damage: 0,
    message: `${fleeingCharacter.name} attempts to flee! `,
  };

  // Attack of opportunity
  const attackOfOpportunity = attack(pursuer, fleeingCharacter);

  // Determine if escape was successful based on DEX check
  switch (fleeSuccess) {
    case SuccessLevel.CRITICAL:
      result.escaped = true;
      result.message += `Critical success! Escaped cleanly. (Roll: ${fleeRoll})`;
      break;

    case SuccessLevel.EXTREME:
      result.escaped = true;
      result.message += `Extreme success! Made a swift escape. (Roll: ${fleeRoll})`;
      break;

    case SuccessLevel.HARD:
      result.escaped = true;
      result.message += `Hard success! Managed to get away. (Roll: ${fleeRoll})`;
      break;

    case SuccessLevel.REGULAR:
      result.escaped = true;
      result.message += `Regular success! Barely escaped. (Roll: ${fleeRoll})`;
      break;

    case SuccessLevel.FAILURE:
      result.escaped = false;
      result.message += `Failed to escape! (Roll: ${fleeRoll})`;
      break;
  }

  // Add attack of opportunity results if any damage was taken
  if (attackOfOpportunity.success) {
    result.damage = attackOfOpportunity.damage;
    result.message += `\n${pursuer.name} lands an attack of opportunity! ${result.damage} damage taken.`;
  }

  return result;
}

function calculateDamage(successLevel, damageFormula) {
  let roll = diceRoll(damageFormula);
  let damage = roll.total;

  if (successLevel === SuccessLevel.EXTREME) {
    damage = roll.maxTotal;
  }

  return damage;
}

// Health status constants
export const HealthStatus = {
  HEALTHY: "Healthy",
  INJURED: "Injured",
  SERIOUSLY_WOUNDED: "Seriously Wounded",
  CRITICALLY_WOUNDED: "Critically Wounded",
  UNCONSCIOUS: "Unconscious",
  DEAD: "Dead",
};

export function calculateHealthStatus(currentHP, maxHP) {
  // Ensure we're working with numbers
  currentHP = Number(currentHP);
  maxHP = Number(maxHP);

  // Calculate percentage of health remaining
  const healthPercentage = (currentHP / maxHP) * 100;

  // Calculate various threshold points
  const majorWoundThreshold = Math.floor(maxHP / 2);
  const unconsciousThreshold = 2; // Standard CoC rule

  const result = {
    status: HealthStatus.HEALTHY,
    healthPercentage: healthPercentage,
    isStable: true,
    message: "",
    needsFirstAid: false,
    canAct: true,
  };

  // Determine status based on current HP
  if (currentHP <= 0) {
    result.status = HealthStatus.DEAD;
    result.message = "Dead.";
    result.isStable = true; // Technically stable, just... dead
    result.needsFirstAid = false;
    result.canAct = false;
  } else if (currentHP <= unconsciousThreshold) {
    result.status = HealthStatus.UNCONSCIOUS;
    result.message = "Unconscious.";
    result.isStable = false;
    result.needsFirstAid = true;
    result.canAct = false;
  } else if (currentHP <= Math.ceil(maxHP * 0.2)) {
    result.status = HealthStatus.CRITICALLY_WOUNDED;
    result.message = "Critically wounded";
    result.isStable = false;
    result.needsFirstAid = true;
    result.canAct = true;
  } else if (currentHP <= majorWoundThreshold) {
    result.status = HealthStatus.SERIOUSLY_WOUNDED;
    result.message = "Seriously wounded.";
    result.isStable = false;
    result.needsFirstAid = true;
    result.canAct = true;
  } else if (currentHP < maxHP) {
    result.status = HealthStatus.INJURED;
    result.message = "Injured but functional.";
    result.isStable = true;
    result.needsFirstAid = true;
    result.canAct = true;
  } else {
    result.status = HealthStatus.HEALTHY;
    result.message = "In good health.";
    result.needsFirstAid = false;
  }

  // Add specific mechanical effects based on status
  result.mechanicalEffects = getMechanicalEffects(result.status);

  return result;
}

function getMechanicalEffects(status) {
  switch (status) {
    case HealthStatus.HEALTHY:
      return {
        skillPenalty: 0,
        movementPenalty: 0,
        description: "No penalties",
      };

    case HealthStatus.INJURED:
      return {
        skillPenalty: 10,
        movementPenalty: 0,
        description: "-10% to physical actions",
      };

    case HealthStatus.SERIOUSLY_WOUNDED:
      return {
        skillPenalty: 20,
        movementPenalty: 25,
        description: "-20% to all actions, movement reduced by 25%",
      };

    case HealthStatus.CRITICALLY_WOUNDED:
      return {
        skillPenalty: 40,
        movementPenalty: 50,
        description: "-40% to all actions, movement reduced by 50%",
      };

    case HealthStatus.UNCONSCIOUS:
      return {
        skillPenalty: 100,
        movementPenalty: 100,
        description: "Cannot perform any actions",
      };

    case HealthStatus.DEAD:
      return {
        skillPenalty: 100,
        movementPenalty: 100,
        description: "Character is dead",
      };

    default:
      return {
        skillPenalty: 0,
        movementPenalty: 0,
        description: "Status unknown",
      };
  }
}
