// @Entry
import ChapterIntro from "./ChapterIntro";
import ChapterOne from "./ChapterOne";
import ChapterTwo from "./ChapterTwo";
import EncounterWith from "./EncounterWith";

const scenes = {
  chapter_intro: new ChapterIntro(),
  chapter_one: new ChapterOne(),
  chapter_two: new ChapterTwo(),
  encounter_with: new EncounterWith(),
};

class Entry {
  constructor() {
    this.saved = {};
  }

  nextScene(name) {
    this.scene = scenes[name];
    this.saved.scene = name;
    const messages = this.scene.onStart(this);
    // add snapshot
    return messages?.map((msg) => {
      return { ...msg, snapshot: this.saved };
    });
  }

  onStart(saved) {
    console.log("on start:", saved);
    this.saved = saved
      ? JSON.parse(saved)
      : {
          scene: "chapter_intro",
          tags: [],
          turn: 1,
        };

    if (this.saved?.scene && scenes[this.saved.scene]) {
      return this.nextScene(this.saved.scene);
    } else {
      throw new Error("start scene not found: " + this.saved.scene);
    }
  }

  onGenerate(data) {
    const parsed = JSON.parse(data);
    const content = this.scene?.onGenerate(parsed.content) || parsed.content;

    this.saved.turn += 1;
    return { ...parsed, content: content, snapshot: this.saved };
  }

  onSubmit(data) {
    console.log("on submit:", data);

    const parsed = JSON.parse(data);
    const messages = this.scene?.onSubmit(parsed) || [];

    return messages?.map((msg) => {
      if (msg.role === "divider") this.saved.turn = 1;
      return { ...msg, snapshot: this.saved };
    });
  }
}

export default new Entry();
